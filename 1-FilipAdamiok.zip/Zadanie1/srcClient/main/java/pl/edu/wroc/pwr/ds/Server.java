package pl.edu.wroc.pwr.ds;
import org.apache.xmlrpc.common.TypeConverterFactoryImpl;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.server.XmlRpcServer;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;
import org.apache.xmlrpc.webserver.WebServer;
import org.apache.log4j.Logger;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Vector;
/**
 * Hello world server!
 *
 */

public class Server{
  final static Logger logger = Logger.getLogger(Server.class);
	private static final int port = 8080;
	
	public Integer echo(int x, int y){    //podpunkt 1
		System.out.println("Wynik= "+(x+y));
		return new Integer(x+y);
	}
	
	public void metodaServer(String cos) //podpunkt 3
	{
		System.out.println("To jest super metoda po stronie "+ cos);
	}
	
	public long hashAsync(String tekst)
	{
		long wartoscHash=0;
		
		for(int i=tekst.length()-1;i>=0;i--)
		{
			wartoscHash+=Character.getNumericValue(tekst.charAt(i));
		}
		return wartoscHash;
	}
	

	
	public void sortuj(int[]tab)
	{	
		Arrays.sort(tab);
		
		for(int i=0;i<tab.length;i++)
		{
			System.out.println(tab[i]+" dlugosc ciagu- "+tab.length);
		}
		
		
	}
	
	public int asy(int x){
		System.out.println("... wywo�ano asy - odliczam");
		try{
			Thread.sleep(x);
		} catch(InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
		System.out.println("... asy - koniec odliczania");
		return (123);
	}
	


    // Throws in here is really ugly :(
    public static void main( String[] args ) throws Exception{
      // Using SOUT is realy ugly :(
      logger.info("Preparing server");
      WebServer webServer = new WebServer(port);

      XmlRpcServer xmlRpcServer = webServer.getXmlRpcServer();
      

      PropertyHandlerMapping phm = new PropertyHandlerMapping();
      phm.setVoidMethodEnabled(true);
      /* Load handler definitions from a property file.
       * The property file might look like:
       *   Calculator=org.apache.xmlrpc.demo.Calculator
       *   org.apache.xmlrpc.demo.proxy.Adder=org.apache.xmlrpc.demo.proxy.AdderImpl
       */
      phm.load(Thread.currentThread().getContextClassLoader(), "MyHandlers.properties");
      /* You may also provide the handler classes directly,
       * like this:
       * phm.addHandler("Calculator",
       *     org.apache.xmlrpc.demo.Calculator.class);
       * phm.addHandler(org.apache.xmlrpc.demo.proxy.Adder.class.getName(),
       *     org.apache.xmlrpc.demo.proxy.AdderImpl.class);
       */
      phm.addHandler("mojserwer", Server.class);
      phm.addHandler("Hello2", Hello.class);
      xmlRpcServer.setHandlerMapping(phm);
      Server mojserwer=new Server();
      
      XmlRpcServerConfigImpl serverConfig =  (XmlRpcServerConfigImpl) xmlRpcServer.getConfig();
      serverConfig.setEnabledForExtensions(true);
      serverConfig.setContentLengthOptional(false);
      // Using SOUT is realy ugly :(
      logger.info("Starting server");
      webServer.start();
      
		System.out.println("wynik: " + mojserwer.echo(17,21)); //podpunkt 2
    }
}
