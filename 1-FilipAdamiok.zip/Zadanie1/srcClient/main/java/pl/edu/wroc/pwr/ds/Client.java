package pl.edu.wroc.pwr.ds;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import java.net.URL;
import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.Vector;
/**
 * Hello world client!
 *
 */



  	

public class Client{
	
	
	public void metodaClient(String cos)  // podpunkt 3
	{
		System.out.println("To jest super metoda po stronie "+cos);
	}



  	final static Logger logger = Logger.getLogger(Client.class);
	// Throws in here is really ugly :(
    @SuppressWarnings("deprecation")
	public static void main( String[] args ) throws Exception{
      	// Using SOUT is realy ugly :(
      	logger.info("Przygotuj client");
	    XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
	    config.setServerURL(new URL("http://127.0.0.1:8080"));
	    config.setEnabledForExtensions(true);
	    XmlRpcClient client = new XmlRpcClient();
	    client.setConfig(config);
	    Object[] params = new Object[]{"Test Client"};
	    Vector<Integer> params2 = new Vector<Integer>();
		params2.addElement(new Integer(17));
		params2.addElement(new Integer(21));
	    Object result = client.execute("mojserwer.echo", params2);// podpunkt 2
		int wynik = ((Integer) result).intValue();
		System.out.println("wynik: " + wynik);
      	// Using SOUT is realy ugly :(
      	logger.info("Calling hello");
	    client.execute("Hello2.hello", params);
	    logger.info("Metoda dowolna server");
	    Object[] params3 = new Object[]{"serwera"};
	    client.execute("mojserwer.metodaServer", params3);
	    
	    logger.info("Metoda dowolna client");
	    Client cl=new Client();
	    cl.metodaClient("klienta");
	    
	    ClientCallBack ccb=new ClientCallBack();
	    
	    
	   /*ArrayList<Object>lista1=new ArrayList<Object>();
	    lista1.add(30);
	    lista1.add(23);
	    lista1.add(48);
	    lista1.add(1);
	    lista1.add(8);*/
	    
	   //for(int i=0;i<5;i++)
	    //	System.out.println(lista1.get(i));
	    
	 
	    int[] lista1=new int[] {new Integer(30),new Integer(23),new Integer(48)};
	    //Object[] lista1=new Object[] {new Integer(30),new Integer(23)};
	    logger.info("Metoda sortowanie");
	    
	    int[][]lista2=new int[1][lista1.length];
	    for(int i=0;i<lista1.length;i++)
	    lista2[0][i]=lista1[i];
	    client.executeAsync("mojserwer.sortuj",lista2,ccb);//lista w liscie
	    
	    
	    lista1=new int[] {new Integer(30),new Integer(23),new Integer(48),new Integer(1)};
	    lista2=new int[1][lista1.length];
	    for(int i=0;i<lista1.length;i++)
		    lista2[0][i]=lista1[i];
	    client.executeAsync("mojserwer.sortuj",lista2,ccb);
	    
	    lista1=new int[] {new Integer(30),new Integer(23),new Integer(48),new Integer(1),new Integer(29)};
	    lista2=new int[1][lista1.length];
	    for(int i=0;i<lista1.length;i++)
		    lista2[0][i]=lista1[i];
	    client.executeAsync("mojserwer.sortuj",lista2,ccb);
	    
	    lista1=new int[] {new Integer(30),new Integer(23),new Integer(48),new Integer(1),new Integer(29),new Integer(4)};
	    lista2=new int[1][lista1.length];
	    for(int i=0;i<lista1.length;i++)
		    lista2[0][i]=lista1[i];
	    client.executeAsync("mojserwer.sortuj",lista2,ccb);
	    
	    lista1=new int[] {new Integer(30),new Integer(23),new Integer(48),new Integer(1),new Integer(29),new Integer(4),new Integer(5)};
	    lista2=new int[1][lista1.length];
	    for(int i=0;i<lista1.length;i++)
		    lista2[0][i]=lista1[i];
	    client.executeAsync("mojserwer.sortuj",lista2,ccb);
	    
	    
	    
	    ArrayList<String>listaZajecia=new ArrayList<String>();
	    String tekst="FajnyTekst";
	    listaZajecia.add(tekst);
	    
	    client.executeAsync("mojserwer.hashAsync", listaZajecia,ccb);
	    
	    Thread.sleep(10000);
   
    }
    
}
