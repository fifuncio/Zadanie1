package pl.edu.wroc.pwr.ds;
import org.apache.xmlrpc.XmlRpcRequest;
import org.apache.xmlrpc.client.AsyncCallback;
/**
 * Hello world client!
 *
 */
public class ClientCallBack implements AsyncCallback{
	
	
	
	@Override
	public void handleError(XmlRpcRequest request, Throwable t) {
	    System.out.println("Blad");
	    t.printStackTrace();

	}

	@Override
	public void handleResult(XmlRpcRequest request, Object result) {
	    System.out.println("Wynik");
	    System.out.println(request.getMethodName() + ": " + result);
	}
	}
 	

